// ============================================================================
// Ressoa.nro - app completo: Início, Buscar, Biblioteca (playlists) e Ouvindo.
// UI em modo texto (console do libnx) para a v1; a lógica está separada para
// você trocar por SDL2/Borealis depois sem mexer em IPC/persistência.
// A reprodução NÃO acontece aqui: este app só comanda o sysmodule 'ressoad'.
// ============================================================================
#include <switch.h>
#include <curl/curl.h>
#include <atomic>
#include <cstdio>
#include <deque>
#include <functional>
#include <cstring>
#include <memory>
#include <string>
#include <vector>
#include "ipc_client.hpp"
#include "source.hpp"
#include "store.hpp"

namespace {
enum Tab { T_HOME, T_SEARCH, T_LIB, T_NOW, T_COUNT };
const char* TAB_NAMES[T_COUNT] = {"Inicio", "Buscar", "Biblioteca", "Ouvindo"};
const char* STATE_NAMES[] = {"Parado", "Tocando", "Pausado", "Carregando", "Erro"};
const char* REPEAT_NAMES[] = {"Desligado", "Todas", "Faixa"};

struct App {
    Settings cfg;
    std::unique_ptr<MusicSource> src;
    std::vector<Playlist> pls;
    std::vector<Track> home, results;
    int tab = T_HOME, sel[T_COUNT] = {};
    int openPl = -1;                  // playlist aberta na Biblioteca (-1 = lista de playlists)
    bool picking = false;             // seletor "adicionar à playlist"
    Track pickTrack; int pickSel = 0;
    int confirmDel = -1;              // exclusão de playlist precisa de 2 toques em Y
    std::string msg;
    RessoaStatus st{};
    bool dirty = true, needHome = false;
    std::string lastQuery;            // última pesquisa (mostrada na barra)
    int listTop = 2;                  // linha do console onde a lista começa (para o toque)
} A;

// ---- Thread de IPC: a UI NUNCA bloqueia falando com o sysmodule ----
Mutex g_mtx;
std::deque<std::function<void()>> g_jobs;
RessoaStatus g_stShared{};
std::atomic<bool> g_linked{false}, g_run{true};
std::atomic<u64> g_callStart{0};   // tick do início da chamada IPC em andamento (0 = nenhuma)
Thread g_th;

void ipcPost(std::function<void()> f) {
    mutexLock(&g_mtx); g_jobs.push_back(std::move(f)); mutexUnlock(&g_mtx);
}

void ipcWorker(void*) {
    u64 lastPoll = 0;
    while (g_run) {
        if (!g_linked) {
            g_callStart = armGetSystemTick();
            Result rc = ressoaConnect();
            g_callStart = 0;
            if (R_SUCCEEDED(rc)) g_linked = true; else { svcSleepThread(1000000000ULL); continue; }
        }
        std::function<void()> job; bool has = false;
        mutexLock(&g_mtx);
        if (!g_jobs.empty()) { job = std::move(g_jobs.front()); g_jobs.pop_front(); has = true; }
        mutexUnlock(&g_mtx);
        if (has) { g_callStart = armGetSystemTick(); job(); g_callStart = 0; continue; }

        u64 now = armGetSystemTick();
        if (armTicksToNs(now - lastPoll) > 500000000ULL) {
            RessoaStatus st;
            g_callStart = now;
            Result rc = ressoaStatus(&st);
            g_callStart = 0;
            if (R_SUCCEEDED(rc)) { mutexLock(&g_mtx); g_stShared = st; mutexUnlock(&g_mtx); }
            lastPoll = now;
        }
        svcSleepThread(20000000ULL);
    }
}

// Texto de diagnóstico do sysmodule
const char* ipcStatusText() {
    u64 cs = g_callStart;
    if (cs && armTicksToNs(armGetSystemTick() - cs) > 3000000000ULL) return "NAO RESPONDE";
    return g_linked ? "online" : "procurando...";
}

// Rede só é iniciada quando precisa (buscar/Início), nunca no boot do app
bool g_netUp = false;
bool ensureNet() {
    if (g_netUp) return true;
    store::log("nro: iniciando rede");
    nifmInitialize(NifmServiceType_User);
    csrngInitialize();
    Result rc = socketInitializeDefault();
    curl_global_init(CURL_GLOBAL_DEFAULT);
    g_netUp = R_SUCCEEDED(rc);
    store::log("nro: rede %s (rc=0x%x)", g_netUp ? "ok" : "FALHOU", rc);
    if (!g_netUp) A.msg = "Sem rede (socket falhou). Abra pelo hbmenu normal e confira o Wi-Fi";
    return g_netUp;
}

// ---- Persistência de playlists (+ avisa o sysmodule para atualizar o cache) ----
void savePlaylists() {
    store::save("playlists.json", A.pls);
    ipcPost([] { ressoaCmd(RIPC_Reload); });
}

// ---- Teclado do sistema ----
bool askText(const char* guide, std::string& out) {
    SwkbdConfig kbd;
    if (R_FAILED(swkbdCreate(&kbd, 0))) return false;
    swkbdConfigMakePresetDefault(&kbd);
    swkbdConfigSetGuideText(&kbd, guide);
    char buf[128] = {0};
    Result rc = swkbdShow(&kbd, buf, sizeof(buf));
    swkbdClose(&kbd);
    if (R_FAILED(rc) || !buf[0]) return false;
    out = buf;
    return true;
}

// ---- Dados ----
void loadHome() {
    A.home.clear();
    if (!ensureNet()) return;
    std::vector<Track> hist;
    store::load("history.json", hist);
    for (size_t i = 0; i < hist.size() && i < 10; i++) A.home.push_back(hist[i]);   // recentes
    for (auto& t : A.src->popular(20)) A.home.push_back(t);                          // em alta
    if (A.home.empty()) A.msg = "Sem dados. Verifique o Wi-Fi e o client_id em settings.json";
}

std::vector<Track>* currentList() {
    if (A.tab == T_HOME) return &A.home;
    if (A.tab == T_SEARCH) return &A.results;
    if (A.tab == T_LIB && A.openPl >= 0 && A.openPl < (int)A.pls.size()) return &A.pls[A.openPl].tracks;
    return nullptr;
}

// Escreve a fila em queue.json e manda o sysmodule tocar a partir de 'start'
void playFrom(const std::vector<Track>& v, int start) {
    if (!g_linked) { A.msg = "Sysmodule ressoad nao conectado (reinicie o console)"; return; }
    if (!store::save("queue.json", v)) { A.msg = "Falha ao gravar queue.json"; return; }
    ipcPost([start] { ressoaCmdArg(RIPC_LoadQueue, (u32)start); });
    A.msg = "Enviado ao sysmodule...";
}

// ---- Desenho ----
void row(bool cur, const Track& t) {
    printf("%c %-38.38s %-22.22s %2d:%02d\n", cur ? '>' : ' ', t.title.c_str(), t.artist.c_str(), t.duration / 60, t.duration % 60);
}

void drawList(int sel, int total, auto&& rowFn) {
    int start = sel > 14 ? sel - 14 : 0;
    for (int i = start; i < total && i < start + 28; i++) rowFn(i, i == sel);
    if (total == 0) printf("  (vazio)\n");
}

void drawBar(int pos, int dur, int width) {
    int filled = dur > 0 ? (int)((long)pos * width / dur) : 0;
    if (filled > width) filled = width;
    printf("[");
    for (int i = 0; i < width; i++) putchar(i < filled ? '=' : '-');
    printf("]");
}

struct Btn { const char* label; int x0, x1; };
Btn g_btns[5] = {{"[ << ]", 0, 0}, {"[ PLAY/PAUSA ]", 0, 0}, {"[ >> ]", 0, 0}, {"[ VOL- ]", 0, 0}, {"[ VOL+ ]", 0, 0}};

void render() {
    consoleClear();
    for (int i = 0; i < T_COUNT; i++) printf(i == A.tab ? "[%s] " : " %s  ", TAB_NAMES[i]);
    printf("  sysmodule: %s\n--------------------------------------------------------------------------------\n", ipcStatusText());

    if (A.picking) {
        printf("Adicionar \"%s\" a qual playlist?\n\n", A.pickTrack.title.c_str());
        A.listTop = 4;
        drawList(A.pickSel, (int)A.pls.size() + 1, [&](int i, bool cur) {
            printf("%c %s\n", cur ? '>' : ' ', i < (int)A.pls.size() ? A.pls[i].name.c_str() : "[+ Nova playlist]");
        });
    } else if (A.tab == T_NOW) {
        printf("\n  Estado : %s\n  Faixa  : %s\n  Artista: %s\n\n  ", STATE_NAMES[A.st.state % 5], A.st.title, A.st.artist);
        drawBar((int)A.st.position, (int)A.st.duration, 50);
        printf(" %d:%02d/%d:%02d\n\n  Volume : %u%%   Repetir: %s   Fila: %u/%u\n", A.st.position / 60, A.st.position % 60,
               A.st.duration / 60, A.st.duration % 60, A.st.volume, REPEAT_NAMES[A.st.repeat % 3],
               A.st.count ? A.st.index + 1 : 0, A.st.count);
    } else if (A.tab == T_LIB && A.openPl < 0) {
        A.listTop = 2;
        drawList(A.sel[T_LIB], (int)A.pls.size(), [&](int i, bool cur) {
            printf("%c %-40.40s %zu faixas\n", cur ? '>' : ' ', A.pls[i].name.c_str(), A.pls[i].tracks.size());
        });
    } else if (auto* l = currentList()) {
        if (A.tab == T_LIB) { printf("< Voltar   Playlist: %s\n\n", A.pls[A.openPl].name.c_str()); A.listTop = 4; }
        else if (A.tab == T_SEARCH) {
            printf("  [ Pesquisar: %-50.50s ]\n\n", A.lastQuery.empty() ? "toque aqui" : A.lastQuery.c_str());
            A.listTop = 4;
        } else A.listTop = 2;
        drawList(A.sel[A.tab], (int)l->size(), [&](int i, bool cur) { row(cur, (*l)[i]); });
    }

    printf("\x1b[39;1H%s", A.msg.c_str());
    printf("\x1b[40;1H--------------------------------------------------------------------------------");
    printf("\x1b[41;1H %s %-40.40s - %-28.28s", A.st.state == RS_Playing ? ">" : "||", A.st.title, A.st.artist);
    // Botões de toque (linha 42, base 0)
    printf("\x1b[43;1H  ");
    int col = 2;
    for (auto& b : g_btns) {
        b.x0 = col; printf("%s", b.label); col += (int)strlen(b.label); b.x1 = col;
        printf("   "); col += 3;
    }
    printf("\x1b[45;1H L/R aba|A ok|B voltar|X acao|Y +playlist|ZL/ZR ant/prox|-pausa|+ sair");
}

// ---- Entrada ----
void doSearch() {
    std::string q;
    if (!askText("Buscar musicas, artistas...", q)) return;
    A.lastQuery = q;
    printf("\nBuscando...\n"); consoleUpdate(nullptr);
    if (!ensureNet()) return;
    A.results = A.src->search(q, 30);
    A.sel[T_SEARCH] = 0;
    A.msg = A.results.empty() ? "Nenhum resultado (ou sem conexao)" : "";
}

void newPlaylist() {
    std::string name;
    if (askText("Nome da playlist", name)) { A.pls.push_back({name, {}}); savePlaylists(); }
}

void onInput(u64 d) {
    A.msg.clear();
    // Globais
    if (d & HidNpadButton_L) { A.tab = (A.tab + T_COUNT - 1) % T_COUNT; A.picking = false; return; }
    if (d & HidNpadButton_R) { A.tab = (A.tab + 1) % T_COUNT; A.picking = false; return; }
    if (d & HidNpadButton_ZL)    { ipcPost([] { ressoaCmd(RIPC_Prev); });   return; }
    if (d & HidNpadButton_ZR)    { ipcPost([] { ressoaCmd(RIPC_Next); });   return; }
    if (d & HidNpadButton_Minus) { ipcPost([] { ressoaCmd(RIPC_Toggle); }); return; }

    // Seletor de playlist
    if (A.picking) {
        int total = (int)A.pls.size() + 1;
        if (d & HidNpadButton_Down) A.pickSel = (A.pickSel + 1) % total;
        if (d & HidNpadButton_Up)   A.pickSel = (A.pickSel + total - 1) % total;
        if (d & HidNpadButton_B)    A.picking = false;
        if (d & HidNpadButton_A) {
            if (A.pickSel == (int)A.pls.size()) newPlaylist();
            if (A.pickSel < (int)A.pls.size()) { A.pls[A.pickSel].tracks.push_back(A.pickTrack); savePlaylists(); A.msg = "Adicionada!"; }
            A.picking = false;
        }
        return;
    }

    // Aba Ouvindo
    if (A.tab == T_NOW) {
        u32 vol = A.st.volume, rep = A.st.repeat;
        if (d & HidNpadButton_A)     ipcPost([] { ressoaCmd(RIPC_Toggle); });
        if (d & HidNpadButton_Right) ipcPost([vol] { ressoaCmdArg(RIPC_SetVolume, std::min<u32>(vol + 5, 100)); });
        if (d & HidNpadButton_Left)  ipcPost([vol] { ressoaCmdArg(RIPC_SetVolume, vol >= 5 ? vol - 5 : 0); });
        if (d & HidNpadButton_Y)     ipcPost([rep] { ressoaCmdArg(RIPC_SetRepeat, (rep + 1) % 3); });
        return;
    }

    // Listas
    int count = 0;
    bool plList = (A.tab == T_LIB && A.openPl < 0);
    auto* l = currentList();
    count = plList ? (int)A.pls.size() : (l ? (int)l->size() : 0);
    int& sel = A.sel[A.tab];
    if (d & HidNpadButton_Down) sel = count ? (sel + 1) % count : 0;
    if (d & HidNpadButton_Up)   sel = count ? (sel + count - 1) % count : 0;

    if (plList) {   // lista de playlists
        if (d & HidNpadButton_A && count) { A.openPl = sel; A.sel[T_LIB] = 0; }
        if (d & HidNpadButton_X) newPlaylist();
        if ((d & HidNpadButton_Y) && count) {
            if (A.confirmDel == sel) { A.pls.erase(A.pls.begin() + sel); savePlaylists(); A.confirmDel = -1; sel = 0; }
            else { A.confirmDel = sel; A.msg = "Aperte Y de novo para excluir a playlist"; }
        }
        return;
    }
    A.confirmDel = -1;
    if (d & HidNpadButton_B && A.tab == T_LIB) { A.openPl = -1; return; }
    if (!l || !count) { if (A.tab == T_SEARCH && (d & (HidNpadButton_A | HidNpadButton_X))) doSearch(); return; }

    if (d & HidNpadButton_A) playFrom(*l, sel);
    if (d & HidNpadButton_Y) { A.pickTrack = (*l)[sel]; A.pickSel = 0; A.picking = true; }
    if (d & HidNpadButton_X) {
        if (A.tab == T_SEARCH) doSearch();
        else if (A.tab == T_HOME) { printf("\nAtualizando...\n"); consoleUpdate(nullptr); loadHome(); }
        else if (A.tab == T_LIB) { l->erase(l->begin() + sel); savePlaylists(); if (sel > 0) sel--; }   // remove faixa da playlist
    }
}

// ---- Toque (tela 1280x720; console = células de 16x16) ----
bool hitList(int row, int& idx) {
    int count, sel;
    if (A.picking) { count = (int)A.pls.size() + 1; sel = A.pickSel; }
    else if (A.tab == T_LIB && A.openPl < 0) { count = (int)A.pls.size(); sel = A.sel[T_LIB]; }
    else {
        auto* l = currentList();
        if (!l) return false;
        count = (int)l->size(); sel = A.sel[A.tab];
    }
    int start = sel > 14 ? sel - 14 : 0, r = row - A.listTop;
    if (r < 0 || r >= 28) return false;
    idx = start + r;
    return idx < count;
}

void onTouch(int x, int y) {
    int col = x / 16, row = y / 16;
    A.msg.clear();
    if (row == 0) {                                   // abas
        int c = 0;
        for (int i = 0; i < T_COUNT; i++) {
            int w = (int)strlen(TAB_NAMES[i]) + 3;
            if (col < c + w) { A.tab = i; A.picking = false; return; }
            c += w;
        }
        return;
    }
    if (row == 40) { ipcPost([] { ressoaCmd(RIPC_Toggle); }); return; }   // toque na faixa atual = play/pausa
    if (row == 42) {                                  // botões
        u32 vol = A.st.volume;
        for (int i = 0; i < 5; i++) {
            if (col < g_btns[i].x0 - 1 || col > g_btns[i].x1) continue;
            if (i == 0) ipcPost([] { ressoaCmd(RIPC_Prev); });
            if (i == 1) ipcPost([] { ressoaCmd(RIPC_Toggle); });
            if (i == 2) ipcPost([] { ressoaCmd(RIPC_Next); });
            if (i == 3) ipcPost([vol] { ressoaCmdArg(RIPC_SetVolume, vol >= 10 ? vol - 10 : 0); });
            if (i == 4) ipcPost([vol] { ressoaCmdArg(RIPC_SetVolume, std::min<u32>(vol + 10, 100)); });
            return;
        }
        return;
    }
    if (A.picking == false && A.tab == T_SEARCH && (row == 2 || row == 3)) { doSearch(); return; }   // barra de pesquisa
    if (A.picking == false && A.tab == T_LIB && A.openPl >= 0 && row == 2) { A.openPl = -1; return; } // "< Voltar"
    int idx;
    if (hitList(row, idx)) {                          // toque num item = selecionar + confirmar
        if (A.picking) A.pickSel = idx;
        else A.sel[A.tab] = idx;
        onInput(HidNpadButton_A);
    }
}
}  // namespace

int main() {
    consoleInit(nullptr);
    store::ensureDirs();
    store::log("nro: inicio");
    printf("Ressoa 1.0 - iniciando...\n"); consoleUpdate(nullptr);   // desenha ANTES de qualquer serviço

    padConfigureInput(1, HidNpadStyleSet_NpadStandard);
    PadState pad; padInitializeDefault(&pad);
    store::log("nro: pad ok");

    hidInitializeTouchScreen();
    mutexInit(&g_mtx);
    if (!store::load("settings.json", A.cfg)) store::save("settings.json", A.cfg);   // cria padrão
    store::load("playlists.json", A.pls);
    A.src = makeSource(A.cfg);

    // Thread de IPC (pode travar sem derrubar a UI)
    if (R_SUCCEEDED(threadCreate(&g_th, ipcWorker, nullptr, nullptr, 0x10000, 0x2C, -2))) threadStart(&g_th);
    store::log("nro: thread ipc iniciada");

    if (A.cfg.client_id.rfind("COLOQUE", 0) == 0)
        A.msg = "Edite sdmc:/config/ressoa/settings.json e coloque seu client_id do Jamendo";
    else A.needHome = true;

    u64 lastPoll = 0;
    s32 prevTouch = 0;
    store::log("nro: loop");
    while (appletMainLoop()) {
        padUpdate(&pad);
        u64 down = padGetButtonsDown(&pad);
        if (down & HidNpadButton_Plus) break;
        if (down) { onInput(down); A.dirty = true; }

        HidTouchScreenState ts = {};
        hidGetTouchScreenStates(&ts, 1);
        if (ts.count > 0 && prevTouch == 0) { onTouch((int)ts.touches[0].x, (int)ts.touches[0].y); A.dirty = true; }
        prevTouch = ts.count;

        u64 now = armGetSystemTick();
        if (armTicksToNs(now - lastPoll) > 500000000ULL) {   // copia o status vindo da thread de IPC
            RessoaStatus s;
            mutexLock(&g_mtx); s = g_stShared; mutexUnlock(&g_mtx);
            if (memcmp(&s, &A.st, sizeof(s)) != 0) A.st = s;
            lastPoll = now;
            A.dirty = true;   // atualiza o texto de diagnóstico também
        }
        if (A.dirty) { render(); A.dirty = false; consoleUpdate(nullptr); }
        if (A.needHome) { A.needHome = false; printf("\nCarregando...\n"); consoleUpdate(nullptr); loadHome(); A.dirty = true; }
        consoleUpdate(nullptr);
    }

    g_run = false;           // não faz join: se o IPC travou, sair mesmo assim
    store::log("nro: saindo");
    consoleExit(nullptr);
    return 0;
}
