// Cliente IPC (usado pelo NRO e pelo overlay). Requer sessão 'sm' aberta ao conectar.
#pragma once
#include "ipc.hpp"

inline Service g_ressoa;
inline bool    g_ressoaOk = false;

inline Result ressoaConnect() {
    if (g_ressoaOk) return 0;
    Result rc = smGetService(&g_ressoa, RESSOA_SERVICE);
    g_ressoaOk = R_SUCCEEDED(rc);
    return rc;
}
inline void ressoaClose() { if (g_ressoaOk) { serviceClose(&g_ressoa); g_ressoaOk = false; } }

inline Result ressoaStatus(RessoaStatus* st) { return serviceDispatchOut(&g_ressoa, RIPC_GetStatus, *st); }
inline Result ressoaCmd(u32 cmd)             { return serviceDispatch(&g_ressoa, cmd); }
inline Result ressoaCmdArg(u32 cmd, u32 v)   { return serviceDispatchIn(&g_ressoa, cmd, v); }
inline Result ressoaLoadPlaylist(u32 idx, u32 start, bool shuffle) {
    RessoaLoadArgs a{idx, start, shuffle ? 1u : 0u};
    return serviceDispatchIn(&g_ressoa, RIPC_LoadPlaylist, a);
}
inline Result ressoaPlaylist(u32 idx, RessoaPlaylistInfo* out) {
    return serviceDispatchInOut(&g_ressoa, RIPC_GetPlaylist, idx, *out);
}
