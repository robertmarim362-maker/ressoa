// ============================================================================
// Ressoa - protocolo IPC compartilhado entre sysmodule (ressoad), NRO e overlay
// ============================================================================
#pragma once
#include <switch.h>

#define RESSOA_SERVICE "ressoa"   // nome registrado no 'sm' (máx. 8 chars)
#define RESSOA_VERSION 1

// Comandos IPC
enum : u32 {
    RIPC_GetVersion   = 0,   // out: u32
    RIPC_GetStatus    = 1,   // out: RessoaStatus
    RIPC_Play         = 2,
    RIPC_Pause        = 3,
    RIPC_Toggle       = 4,
    RIPC_Next         = 5,
    RIPC_Prev         = 6,
    RIPC_SetVolume    = 7,   // in: u32 (0..100)
    RIPC_SetRepeat    = 8,   // in: u32 (0=off, 1=todas, 2=faixa)
    RIPC_LoadPlaylist = 9,   // in: RessoaLoadArgs (lê playlists.json)
    RIPC_LoadQueue    = 10,  // in: u32 start (lê queue.json escrito pelo NRO)
    RIPC_Reload       = 11,  // relê playlists.json (após o NRO editar)
    RIPC_GetPlaylist  = 12,  // in: u32 idx, out: RessoaPlaylistInfo
};

// Estados do player
enum : u32 { RS_Stopped = 0, RS_Playing = 1, RS_Paused = 2, RS_Buffering = 3, RS_Error = 4 };

struct RessoaStatus {
    u32 state, index, count, volume, position, duration, repeat, shuffle;
    char title[64];
    char artist[48];
};

struct RessoaPlaylistInfo { u32 count; u32 tracks; char name[48]; };
struct RessoaLoadArgs     { u32 index; u32 start; u32 shuffle; };
