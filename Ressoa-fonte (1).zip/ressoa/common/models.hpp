// Modelos de dados persistidos em JSON (sdmc:/config/ressoa/)
#pragma once
#include <string>
#include <vector>
#include "json.hpp"   // nlohmann/json (baixado por fetch_deps.sh)

// Uma faixa. 'url' é o stream direto (Jamendo/Subsonic). Se vazio, usa 'id' do Jamendo.
struct Track { std::string id, title, artist, url; int duration = 0; };
NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE_WITH_DEFAULT(Track, id, title, artist, url, duration)

struct Playlist { std::string name; std::vector<Track> tracks; };
NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE_WITH_DEFAULT(Playlist, name, tracks)

// Último estado de reprodução (state.json) - gravado pelo sysmodule
struct SavedState {
    std::vector<Track> queue;
    int index = 0, position = 0, volume = 60, repeat = 0;
    bool shuffle = false;
};
NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE_WITH_DEFAULT(SavedState, queue, index, position, volume, repeat, shuffle)

// Configurações do usuário (settings.json)
struct Settings {
    std::string client_id = "COLOQUE_SEU_CLIENT_ID_JAMENDO";
    std::string source = "jamendo";   // "jamendo" | "subsonic" (futuro)
    bool autoresume = false;          // retomar sozinho ao ligar o console
    int default_volume = 60;
};
NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE_WITH_DEFAULT(Settings, client_id, source, autoresume, default_volume)
