// ============================================================================
// Persistência em JSON no SD. Escrita atômica (arquivo .tmp + rename) para não
// corromper playlists se o console desligar no meio da gravação.
// Arquivos: playlists.json, state.json, history.json, settings.json, queue.json
// ============================================================================
#pragma once
#include <switch.h>
#include <sys/stat.h>
#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <string>
#include "models.hpp"

namespace store {
using json = nlohmann::json;
constexpr const char* DIR = "sdmc:/config/ressoa";

inline std::string path(const char* f) { return std::string(DIR) + "/" + f; }
inline void ensureDirs() { mkdir("sdmc:/config", 0777); mkdir(DIR, 0777); }

inline bool readFile(const std::string& p, std::string& out) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    if (n < 0 || n > 8 * 1024 * 1024) { fclose(f); return false; }
    out.resize((size_t)n);
    size_t r = fread(out.data(), 1, (size_t)n, f);
    fclose(f); out.resize(r);
    return true;
}

inline bool writeAtomic(const std::string& p, const std::string& data) {
    std::string tmp = p + ".tmp";
    FILE* f = fopen(tmp.c_str(), "wb");
    if (!f) return false;
    size_t w = fwrite(data.data(), 1, data.size(), f);
    fclose(f);
    if (w != data.size()) return false;
    remove(p.c_str());
    return rename(tmp.c_str(), p.c_str()) == 0;
}

// Carrega qualquer tipo com macro NLOHMANN_DEFINE_TYPE_* (ou vector<T>). Falha = false.
template <class T> bool load(const char* file, T& out) {
    std::string s;
    if (!readFile(path(file), s)) return false;
    try {
        json j = json::parse(s, nullptr, false);
        if (j.is_discarded()) return false;
        out = j.get<T>();
        return true;
    } catch (...) { return false; }
}

template <class T> bool save(const char* file, const T& v) {
    try { return writeAtomic(path(file), json(v).dump(1)); } catch (...) { return false; }
}

// Histórico recente: mais nova primeiro, sem duplicatas, máx. 50
inline void appendHistory(const Track& t, size_t max = 50) {
    std::vector<Track> h;
    load("history.json", h);
    h.erase(std::remove_if(h.begin(), h.end(),
            [&](const Track& x) { return x.id == t.id && x.url == t.url; }), h.end());
    h.insert(h.begin(), t);
    if (h.size() > max) h.resize(max);
    save("history.json", h);
}

// Log simples (limitado a 64 KB) em sdmc:/config/ressoa/log.txt
inline void log(const char* fmt, ...) {
    std::string p = path("log.txt");
    FILE* f = fopen(p.c_str(), "ab");
    if (!f) return;
    if (ftell(f) > 65536) { fclose(f); f = fopen(p.c_str(), "wb"); if (!f) return; }
    va_list a; va_start(a, fmt); vfprintf(f, fmt, a); va_end(a);
    fputc('\n', f); fclose(f);
}
}  // namespace store
