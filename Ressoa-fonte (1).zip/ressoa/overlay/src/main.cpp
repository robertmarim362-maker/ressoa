// ============================================================================
// Ressoa.ovl - overlay Tesla/Ultrahand. NÃO toca áudio: só desenha a UI e
// manda comandos IPC ao sysmodule 'ressoad' (que continua tocando com o jogo).
// ============================================================================
#define TESLA_INIT_IMPL
#include <tesla.hpp>
#include "ipc_client.hpp"

// Cores RGBA4444. Se sua versão do libtesla não expõe a(), troque por tsl::gfx::Color(c).
#define COL(c) a(c)

static RessoaStatus g_st{};
static u64 g_lastPoll = 0, g_lastConnect = 0;

// Atualiza o status a cada 500 ms; tenta reconectar a cada 3 s se o sysmodule estiver offline
static void pollStatus() {
    u64 now = armGetSystemTick();
    if (!g_ressoaOk) {
        if (armTicksToNs(now - g_lastConnect) > 3000000000ULL) {
            g_lastConnect = now;
            tsl::hlp::doWithSmSession([] { ressoaConnect(); });
        }
        return;
    }
    if (armTicksToNs(now - g_lastPoll) < 500000000ULL) return;
    g_lastPoll = now;
    if (R_FAILED(ressoaStatus(&g_st))) ressoaClose();
}

static const char* STATE_TXT[] = {"Parado", "Tocando", "Pausado", "Carregando...", "Erro"};
static const char* REPEAT_TXT[] = {"Desligado", "Todas", "Faixa"};

// ---------------------------------------------------------------------------
// Tela de playlists: A toca em ordem, Y toca embaralhado
// ---------------------------------------------------------------------------
class PlaylistsGui : public tsl::Gui {
public:
    tsl::elm::Element* createUI() override {
        auto* frame = new tsl::elm::OverlayFrame("Playlists", "A tocar  |  Y aleatorio");
        auto* list = new tsl::elm::List();
        RessoaPlaylistInfo info{};
        u32 count = 0;
        if (g_ressoaOk && R_SUCCEEDED(ressoaPlaylist(0, &info))) count = info.count;

        for (u32 i = 0; i < count; i++) {
            if (R_FAILED(ressoaPlaylist(i, &info))) break;
            auto* item = new tsl::elm::ListItem(info.name, std::to_string(info.tracks) + " faixas");
            item->setClickListener([i](u64 keys) {
                if (keys & HidNpadButton_A) { ressoaLoadPlaylist(i, 0, false); tsl::goBack(); return true; }
                if (keys & HidNpadButton_Y) { ressoaLoadPlaylist(i, 0, true);  tsl::goBack(); return true; }
                return false;
            });
            list->addItem(item);
        }
        if (count == 0) list->addItem(new tsl::elm::ListItem("Nenhuma playlist (crie no app)"));
        frame->setContent(list);
        return frame;
    }
};

// ---------------------------------------------------------------------------
// Tela principal: "ouvindo agora" + controles + volume
// ---------------------------------------------------------------------------
class MainGui : public tsl::Gui {
public:
    tsl::elm::Element* createUI() override {
        auto* frame = new tsl::elm::OverlayFrame("Ressoa", "v1.0.0");
        auto* list = new tsl::elm::List();

        // Cartão "ouvindo agora" (título, artista e barra de progresso)
        list->addItem(new tsl::elm::CustomDrawer([](tsl::gfx::Renderer* r, auto x, auto y, auto w, auto h) {
            if (!g_ressoaOk) {
                r->drawString("Sysmodule offline", false, x + 10, y + 30, 20, COL(0xF55F));
                r->drawString("Reinicie o console", false, x + 10, y + 55, 16, COL(0x8888));
                return;
            }
            r->drawString(g_st.title[0] ? g_st.title : "Nada tocando", false, x + 10, y + 28, 20, COL(0xFFFF), w - 20);
            r->drawString(g_st.artist, false, x + 10, y + 52, 16, COL(0x8888), w - 20);
            // barra de progresso
            const s32 bx = x + 10, by = y + 68, bw = w - 20;
            r->drawRect(bx, by, bw, 4, COL(0x3333));
            if (g_st.duration > 0) r->drawRect(bx, by, (s32)((u64)bw * g_st.position / g_st.duration), 4, COL(0x1ECF));
        }), 82);

        playItem_ = new tsl::elm::ListItem("Play / Pausar", "");
        playItem_->setClickListener([](u64 k) { if (k & HidNpadButton_A) { ressoaCmd(RIPC_Toggle); return true; } return false; });
        list->addItem(playItem_);

        auto* nextItem = new tsl::elm::ListItem("Proxima");
        nextItem->setClickListener([](u64 k) { if (k & HidNpadButton_A) { ressoaCmd(RIPC_Next); return true; } return false; });
        list->addItem(nextItem);

        auto* prevItem = new tsl::elm::ListItem("Anterior");
        prevItem->setClickListener([](u64 k) { if (k & HidNpadButton_A) { ressoaCmd(RIPC_Prev); return true; } return false; });
        list->addItem(prevItem);

        repeatItem_ = new tsl::elm::ListItem("Repetir", "");
        repeatItem_->setClickListener([](u64 k) {
            if (k & HidNpadButton_A) { ressoaCmdArg(RIPC_SetRepeat, (g_st.repeat + 1) % 3); return true; }
            return false;
        });
        list->addItem(repeatItem_);

        auto* plItem = new tsl::elm::ListItem("Playlists", ">");
        plItem->setClickListener([](u64 k) { if (k & HidNpadButton_A) { tsl::changeTo<PlaylistsGui>(); return true; } return false; });
        list->addItem(plItem);

        vol_ = new tsl::elm::TrackBar("\uE13C");
        vol_->setProgress((u8)g_st.volume);
        vol_->setValueChangedListener([](u8 v) { ressoaCmdArg(RIPC_SetVolume, v); });
        list->addItem(vol_);

        frame->setContent(list);
        return frame;
    }

    void update() override {
        pollStatus();
        if (!playItem_) return;
        playItem_->setValue(g_ressoaOk ? STATE_TXT[g_st.state % 5] : "offline");
        repeatItem_->setValue(REPEAT_TXT[g_st.repeat % 3]);
    }

private:
    tsl::elm::ListItem *playItem_ = nullptr, *repeatItem_ = nullptr;
    tsl::elm::TrackBar* vol_ = nullptr;
};

class RessoaOverlay : public tsl::Overlay {
public:
    void initServices() override {
        tsl::hlp::doWithSmSession([] { ressoaConnect(); });
        if (g_ressoaOk) ressoaStatus(&g_st);
    }
    void exitServices() override { ressoaClose(); }
    std::unique_ptr<tsl::Gui> loadInitialGui() override { return initially<MainGui>(); }
};

int main(int argc, char** argv) { return tsl::loop<RessoaOverlay>(argc, argv); }
