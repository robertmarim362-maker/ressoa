# Ressoa

Player de música em streaming para Nintendo Switch (Atmosphère + Ultrahand), sem login.

## Componentes
| Parte | Arquivo | Função |
|---|---|---|
| Sysmodule `ressoad` | `exefs.nsp` | rede + decode MP3 + áudio em segundo plano + fila + estado |
| App | `Ressoa.nro` | Início, Buscar, Biblioteca (playlists), Ouvindo |
| Overlay | `Ressoa.ovl` | play/pause, próxima, anterior, volume, repetir, playlists |

## Compilar
1. Instale o devkitPro (switch-dev) e exporte `DEVKITPRO`.
2. `./fetch_deps.sh` (baixa json.hpp, dr_mp3.h e libtesla) e instale os pacotes que ele indicar.
3. `make dist` -> gera `Ressoa.zip`.

## Instalar
Extraia `Ressoa.zip` na raiz do SD, edite `sdmc:/config/ressoa/settings.json` com seu
`client_id` gratuito do Jamendo (https://devportal.jamendo.com) e reinicie o console.
Para iniciar o sysmodule sem reiniciar, ative-o no Ultrahand (menu de sysmodules).

## Arquivos de dados (sdmc:/config/ressoa/)
`playlists.json` (NRO), `queue.json` (NRO -> sysmodule), `state.json` (sysmodule: fila, faixa,
posição, volume, repetição), `history.json` (50 recentes), `settings.json`, `log.txt`.

## Pontos que dependem de versão (revise se o build reclamar)
- `overlay/src/main.cpp`: macro `COL()` (função `a()` do libtesla) e assinatura do lambda do `CustomDrawer`.
- `sysmodule/src/main.cpp`: servidor HIPC feito "na mão" (`writeReply`/`handleRequest`) sobre libnx 4.x.
- `sysmodule/ressoad.json`: compare `kernel_capabilities` com o exemplo de sysmodule do libnx se o Atmosphère recusar o boot.
- `player.cpp`: usa `drmp3dec_decode_frame` (dr_mp3); defina `DR_MP3_FLOAT_OUTPUT` NÃO (precisamos de s16).
- Se o sysmodule falhar por falta de memória, aumente `INNER_HEAP_SIZE` ou reduza `NetStream::RING`.

## Limitações conhecidas da v1
UI do NRO em modo texto; pausa de ~1 s entre faixas (sem prefetch); HTTPS sem validação de certificado;
rede cai ao suspender o console (o sysmodule retoma a faixa pela posição salva).
