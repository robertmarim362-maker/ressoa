// ============================================================================
// Ressoa.nro - app completo: Início, Buscar, Biblioteca (playlists) e Ouvindo.
// UI em modo texto (console do libnx) para a v1; a lógica está separada para
// você trocar por SDL2/Borealis depois sem mexer em IPC/persistência.
// A reprodução NÃO acontece aqui: este app só comanda o sysmodule 'ressoad'.
// ============================================================================
#include <switch.h>
#include <curl/curl.h>
#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <vector>
#include "ipc_client.hpp"
#include "source.hpp"
#include "store.hpp"

namespace {
enum Tab { T_HOME, T_SEARCH, T_LIB, T_NOW, T_COUNT };
const char* TAB_NAMES[T_COUNT] = {"Inicio", "Buscar", "Biblioteca", "Ouvindo"};
const char* STATE_NAMES[] = {"Parado", "Tocando", "Pausado", "Carregando", "Erro"};
const char* REPEAT_NAMES[] = {"Desligado", "Todas", "Faixa"};

struct App {
    Settings cfg;
    std::unique_ptr<MusicSource> src;
    std::vector<Playlist> pls;
    std::vector<Track> home, results;
    int tab = T_HOME, sel[T_COUNT] = {};
    int openPl = -1;                  // playlist aberta na Biblioteca (-1 = lista de playlists)
    bool picking = false;             // seletor "adicionar à playlist"
    Track pickTrack; int pickSel = 0;
    int confirmDel = -1;              // exclusão de playlist precisa de 2 toques em Y
    std::string msg;
    RessoaStatus st{};
    bool linked = false, dirty = true;
} A;

// ---- Persistência de playlists (+ avisa o sysmodule para atualizar o cache) ----
void savePlaylists() {
    store::save("playlists.json", A.pls);
    if (A.linked) ressoaCmd(RIPC_Reload);
}

// ---- Teclado do sistema ----
bool askText(const char* guide, std::string& out) {
    SwkbdConfig kbd;
    if (R_FAILED(swkbdCreate(&kbd, 0))) return false;
    swkbdConfigMakePresetDefault(&kbd);
    swkbdConfigSetGuideText(&kbd, guide);
    char buf[128] = {0};
    Result rc = swkbdShow(&kbd, buf, sizeof(buf));
    swkbdClose(&kbd);
    if (R_FAILED(rc) || !buf[0]) return false;
    out = buf;
    return true;
}

// ---- Dados ----
void loadHome() {
    A.home.clear();
    std::vector<Track> hist;
    store::load("history.json", hist);
    for (size_t i = 0; i < hist.size() && i < 10; i++) A.home.push_back(hist[i]);   // recentes
    for (auto& t : A.src->popular(20)) A.home.push_back(t);                          // em alta
    if (A.home.empty()) A.msg = "Sem dados. Verifique o Wi-Fi e o client_id em settings.json";
}

std::vector<Track>* currentList() {
    if (A.tab == T_HOME) return &A.home;
    if (A.tab == T_SEARCH) return &A.results;
    if (A.tab == T_LIB && A.openPl >= 0 && A.openPl < (int)A.pls.size()) return &A.pls[A.openPl].tracks;
    return nullptr;
}

// Escreve a fila em queue.json e manda o sysmodule tocar a partir de 'start'
void playFrom(const std::vector<Track>& v, int start) {
    if (!A.linked) { A.msg = "Sysmodule ressoad nao esta rodando (reinicie o console)"; return; }
    if (!store::save("queue.json", v)) { A.msg = "Falha ao gravar queue.json"; return; }
    A.msg = R_SUCCEEDED(ressoaCmdArg(RIPC_LoadQueue, (u32)start)) ? "" : "Falha ao iniciar reproducao";
}

// ---- Desenho ----
void row(bool cur, const Track& t) {
    printf("%c %-38.38s %-22.22s %2d:%02d\n", cur ? '>' : ' ', t.title.c_str(), t.artist.c_str(), t.duration / 60, t.duration % 60);
}

void drawList(int sel, int total, auto&& rowFn) {
    int start = sel > 14 ? sel - 14 : 0;
    for (int i = start; i < total && i < start + 28; i++) rowFn(i, i == sel);
    if (total == 0) printf("  (vazio)\n");
}

void drawBar(int pos, int dur, int width) {
    int filled = dur > 0 ? (int)((long)pos * width / dur) : 0;
    if (filled > width) filled = width;
    printf("[");
    for (int i = 0; i < width; i++) putchar(i < filled ? '=' : '-');
    printf("]");
}

void render() {
    consoleClear();
    for (int i = 0; i < T_COUNT; i++) printf(i == A.tab ? "[%s] " : " %s  ", TAB_NAMES[i]);
    printf("\n--------------------------------------------------------------------------------\n");

    if (A.picking) {
        printf("Adicionar \"%s\" a qual playlist?\n\n", A.pickTrack.title.c_str());
        drawList(A.pickSel, (int)A.pls.size() + 1, [&](int i, bool cur) {
            printf("%c %s\n", cur ? '>' : ' ', i < (int)A.pls.size() ? A.pls[i].name.c_str() : "[+ Nova playlist]");
        });
    } else if (A.tab == T_NOW) {
        printf("\n  Estado : %s\n  Faixa  : %s\n  Artista: %s\n\n  ", STATE_NAMES[A.st.state % 5], A.st.title, A.st.artist);
        drawBar((int)A.st.position, (int)A.st.duration, 50);
        printf(" %d:%02d/%d:%02d\n\n  Volume : %u%%   Repetir: %s   Fila: %u/%u\n", A.st.position / 60, A.st.position % 60,
               A.st.duration / 60, A.st.duration % 60, A.st.volume, REPEAT_NAMES[A.st.repeat % 3],
               A.st.count ? A.st.index + 1 : 0, A.st.count);
    } else if (A.tab == T_LIB && A.openPl < 0) {
        drawList(A.sel[T_LIB], (int)A.pls.size(), [&](int i, bool cur) {
            printf("%c %-40.40s %zu faixas\n", cur ? '>' : ' ', A.pls[i].name.c_str(), A.pls[i].tracks.size());
        });
    } else if (auto* l = currentList()) {
        if (A.tab == T_LIB) printf("Playlist: %s\n\n", A.pls[A.openPl].name.c_str());
        drawList(A.sel[A.tab], (int)l->size(), [&](int i, bool cur) { row(cur, (*l)[i]); });
    }

    printf("\x1b[40;1H%s\n", A.msg.c_str());
    printf("\x1b[41;1H--------------------------------------------------------------------------------\n");
    printf(" %s %s - %s\n", A.st.state == RS_Playing ? ">" : "||", A.st.title, A.st.artist);
    printf(" L/R aba | A ok | B voltar | X acao | Y +playlist | ZL/ZR ant/prox | - play/pause | + sair");
}

// ---- Entrada ----
void doSearch() {
    std::string q;
    if (!askText("Buscar musicas, artistas...", q)) return;
    printf("\nBuscando...\n"); consoleUpdate(nullptr);
    A.results = A.src->search(q, 30);
    A.sel[T_SEARCH] = 0;
    A.msg = A.results.empty() ? "Nenhum resultado (ou sem conexao)" : "";
}

void newPlaylist() {
    std::string name;
    if (askText("Nome da playlist", name)) { A.pls.push_back({name, {}}); savePlaylists(); }
}

void onInput(u64 d) {
    A.msg.clear();
    // Globais
    if (d & HidNpadButton_L) { A.tab = (A.tab + T_COUNT - 1) % T_COUNT; A.picking = false; return; }
    if (d & HidNpadButton_R) { A.tab = (A.tab + 1) % T_COUNT; A.picking = false; return; }
    if (A.linked) {
        if (d & HidNpadButton_ZL)    { ressoaCmd(RIPC_Prev); return; }
        if (d & HidNpadButton_ZR)    { ressoaCmd(RIPC_Next); return; }
        if (d & HidNpadButton_Minus) { ressoaCmd(RIPC_Toggle); return; }
    }

    // Seletor de playlist
    if (A.picking) {
        int total = (int)A.pls.size() + 1;
        if (d & HidNpadButton_Down) A.pickSel = (A.pickSel + 1) % total;
        if (d & HidNpadButton_Up)   A.pickSel = (A.pickSel + total - 1) % total;
        if (d & HidNpadButton_B)    A.picking = false;
        if (d & HidNpadButton_A) {
            if (A.pickSel == (int)A.pls.size()) newPlaylist();
            if (A.pickSel < (int)A.pls.size()) { A.pls[A.pickSel].tracks.push_back(A.pickTrack); savePlaylists(); A.msg = "Adicionada!"; }
            A.picking = false;
        }
        return;
    }

    // Aba Ouvindo
    if (A.tab == T_NOW) {
        if (!A.linked) return;
        if (d & HidNpadButton_A)     ressoaCmd(RIPC_Toggle);
        if (d & HidNpadButton_Right) ressoaCmdArg(RIPC_SetVolume, std::min<u32>(A.st.volume + 5, 100));
        if (d & HidNpadButton_Left)  ressoaCmdArg(RIPC_SetVolume, A.st.volume >= 5 ? A.st.volume - 5 : 0);
        if (d & HidNpadButton_Y)     ressoaCmdArg(RIPC_SetRepeat, (A.st.repeat + 1) % 3);
        return;
    }

    // Listas
    int count = 0;
    bool plList = (A.tab == T_LIB && A.openPl < 0);
    auto* l = currentList();
    count = plList ? (int)A.pls.size() : (l ? (int)l->size() : 0);
    int& sel = A.sel[A.tab];
    if (d & HidNpadButton_Down) sel = count ? (sel + 1) % count : 0;
    if (d & HidNpadButton_Up)   sel = count ? (sel + count - 1) % count : 0;

    if (plList) {   // lista de playlists
        if (d & HidNpadButton_A && count) { A.openPl = sel; A.sel[T_LIB] = 0; }
        if (d & HidNpadButton_X) newPlaylist();
        if ((d & HidNpadButton_Y) && count) {
            if (A.confirmDel == sel) { A.pls.erase(A.pls.begin() + sel); savePlaylists(); A.confirmDel = -1; sel = 0; }
            else { A.confirmDel = sel; A.msg = "Aperte Y de novo para excluir a playlist"; }
        }
        return;
    }
    A.confirmDel = -1;
    if (d & HidNpadButton_B && A.tab == T_LIB) { A.openPl = -1; return; }
    if (!l || !count) { if (A.tab == T_SEARCH && (d & (HidNpadButton_A | HidNpadButton_X))) doSearch(); return; }

    if (d & HidNpadButton_A) playFrom(*l, sel);
    if (d & HidNpadButton_Y) { A.pickTrack = (*l)[sel]; A.pickSel = 0; A.picking = true; }
    if (d & HidNpadButton_X) {
        if (A.tab == T_SEARCH) doSearch();
        else if (A.tab == T_HOME) { printf("\nAtualizando...\n"); consoleUpdate(nullptr); loadHome(); }
        else if (A.tab == T_LIB) { l->erase(l->begin() + sel); savePlaylists(); if (sel > 0) sel--; }   // remove faixa da playlist
    }
}
}  // namespace

int main() {
    consoleInit(nullptr);
    padConfigureInput(1, HidNpadStyleSet_NpadStandard);
    PadState pad; padInitializeDefault(&pad);

    nifmInitialize(NifmServiceType_User);
    csrngInitialize();
    socketInitializeDefault();
    curl_global_init(CURL_GLOBAL_DEFAULT);

    store::ensureDirs();
    if (!store::load("settings.json", A.cfg)) store::save("settings.json", A.cfg);   // cria padrão
    store::load("playlists.json", A.pls);
    A.src = makeSource(A.cfg);
    A.linked = R_SUCCEEDED(ressoaConnect());
    if (A.cfg.client_id.rfind("COLOQUE", 0) == 0) A.msg = "Edite sdmc:/config/ressoa/settings.json e coloque seu client_id do Jamendo";

    printf("Carregando...\n"); consoleUpdate(nullptr);
    if (A.msg.empty()) loadHome();

    u64 lastPoll = 0;
    while (appletMainLoop()) {
        padUpdate(&pad);
        u64 down = padGetButtonsDown(&pad);
        if (down & HidNpadButton_Plus) break;
        if (down) { onInput(down); A.dirty = true; }

        u64 now = armGetSystemTick();
        if (A.linked && armTicksToNs(now - lastPoll) > 500000000ULL) {   // atualiza "ouvindo agora"
            RessoaStatus s;
            if (R_SUCCEEDED(ressoaStatus(&s)) && memcmp(&s, &A.st, sizeof(s)) != 0) { A.st = s; A.dirty = true; }
            lastPoll = now;
        }
        if (A.dirty) { render(); A.dirty = false; }
        consoleUpdate(nullptr);
    }

    ressoaClose();
    curl_global_cleanup();
    socketExit(); csrngExit(); nifmExit();
    consoleExit(nullptr);
    return 0;
}
