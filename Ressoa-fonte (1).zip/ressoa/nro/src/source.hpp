// ============================================================================
// Fontes de música. MusicSource é a interface; JamendoSource é a implementação
// principal. SubsonicSource é um esqueleto para quando você tiver um servidor
// Navidrome/Subsonic (aí o Track.url já vem pronto com a URL de stream).
// ============================================================================
#pragma once
#include <curl/curl.h>
#include <memory>
#include <string>
#include <vector>
#include "models.hpp"

struct MusicSource {
    virtual ~MusicSource() = default;
    virtual const char* name() const = 0;
    virtual std::vector<Track> popular(int limit) = 0;
    virtual std::vector<Track> search(const std::string& query, int limit) = 0;
};

inline size_t curlToString(char* p, size_t s, size_t n, void* ud) {
    static_cast<std::string*>(ud)->append(p, s * n);
    return s * n;
}

// GET simples. HTTPS sem verificação de CA (hbmenu não traz bundle de certificados).
inline bool httpGet(const std::string& url, std::string& body) {
    CURL* c = curl_easy_init();
    if (!c) return false;
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(c, CURLOPT_USERAGENT, "Ressoa/1.0 (Nintendo Switch)");
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 20L);
    curl_easy_setopt(c, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(c, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, curlToString);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &body);
    CURLcode rc = curl_easy_perform(c);
    long code = 0;
    curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &code);
    curl_easy_cleanup(c);
    return rc == CURLE_OK && code == 200;
}

inline std::string urlEncode(const std::string& s) {
    CURL* c = curl_easy_init();
    char* e = c ? curl_easy_escape(c, s.c_str(), (int)s.size()) : nullptr;
    std::string r = e ? e : "";
    if (e) curl_free(e);
    if (c) curl_easy_cleanup(c);
    return r;
}

// --- Jamendo (API v3, gratuita; exige um client_id de desenvolvedor, não conta de usuário) ---
class JamendoSource : public MusicSource {
public:
    explicit JamendoSource(std::string clientId) : id_(std::move(clientId)) {}
    const char* name() const override { return "Jamendo"; }
    std::vector<Track> popular(int limit) override { return fetch("&order=popularity_week", limit); }
    std::vector<Track> search(const std::string& q, int limit) override { return fetch("&search=" + urlEncode(q), limit); }

private:
    using json = nlohmann::json;
    static std::string str(const json& j, const char* k) {   // id pode vir como string ou número
        if (!j.contains(k) || j[k].is_null()) return "";
        return j[k].is_string() ? j[k].get<std::string>() : j[k].dump();
    }
    std::vector<Track> fetch(const std::string& extra, int limit) {
        std::vector<Track> out;
        std::string body;
        std::string url = "https://api.jamendo.com/v3.0/tracks/?format=json&audioformat=mp31&limit=" +
                          std::to_string(limit) + "&client_id=" + id_ + extra;
        if (!httpGet(url, body)) return out;
        try {
            json j = json::parse(body, nullptr, false);
            if (j.is_discarded() || !j.contains("results")) return out;
            for (const auto& r : j["results"]) {
                Track t;
                t.id = str(r, "id"); t.title = str(r, "name"); t.artist = str(r, "artist_name");
                t.url = str(r, "audio");
                try { t.duration = std::stoi(str(r, "duration")); } catch (...) {}
                if (!t.url.empty() || !t.id.empty()) out.push_back(std::move(t));
            }
        } catch (...) {}
        return out;
    }
    std::string id_;
};

// --- Subsonic/Navidrome (esqueleto): implementar auth por token (md5(senha+salt)) e
//     preencher Track.url = <servidor>/rest/stream?id=...&u=...&t=...&s=...&v=1.16.1&c=ressoa
class SubsonicSource : public MusicSource {
public:
    const char* name() const override { return "Subsonic (em breve)"; }
    std::vector<Track> popular(int) override { return {}; }
    std::vector<Track> search(const std::string&, int) override { return {}; }
};

inline std::unique_ptr<MusicSource> makeSource(const Settings& s) {
    if (s.source == "subsonic") return std::make_unique<SubsonicSource>();
    return std::make_unique<JamendoSource>(s.client_id);
}
