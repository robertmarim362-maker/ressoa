#!/bin/sh
# Baixa as dependências de terceiros (header-only / libtesla). Rode uma vez.
set -e
cd "$(dirname "$0")"
mkdir -p third_party
curl -L -o third_party/json.hpp  https://github.com/nlohmann/json/releases/download/v3.11.3/json.hpp
curl -L -o third_party/dr_mp3.h  https://raw.githubusercontent.com/mackron/dr_libs/master/dr_mp3.h
[ -d overlay/libs/libtesla ] || { mkdir -p overlay/libs && git clone --depth 1 https://github.com/WerWolv/libtesla overlay/libs/libtesla; }
echo "Bibliotecas do devkitPro (rode uma vez):"
echo "  sudo dkp-pacman -S --needed switch-dev switch-curl switch-mbedtls switch-zlib"
