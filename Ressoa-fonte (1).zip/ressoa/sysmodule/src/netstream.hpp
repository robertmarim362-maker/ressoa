// ============================================================================
// NetStream: baixa uma URL (HTTP/HTTPS via libcurl) numa thread própria e expõe
// os bytes por um ring buffer SPSC (sem lock). Um objeto por faixa: destruir o
// objeto aborta o download. Se o buffer enche, o download pausa (backpressure).
// ============================================================================
#pragma once
#include <switch.h>
#include <curl/curl.h>
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

class NetStream {
public:
    static constexpr size_t RING = 384 * 1024;   // ~25 s de áudio a 128 kbps

    explicit NetStream(const std::string& url) : url_(url), ring_(RING) {
        if (R_SUCCEEDED(threadCreate(&th_, &NetStream::entry, this, nullptr, 0x20000, 0x2C, -2))) {
            threadStart(&th_);
            started_ = true;
        } else {
            failed_ = true; done_ = true;
        }
    }
    ~NetStream() {
        abort_ = true;
        if (started_) { threadWaitForExit(&th_); threadClose(&th_); }
    }

    size_t available() const { return head_.load(std::memory_order_acquire) - tail_.load(std::memory_order_relaxed); }
    bool done() const   { return done_; }
    bool failed() const { return failed_; }

    // Consumidor: copia até 'max' bytes (não bloqueia)
    size_t read(uint8_t* dst, size_t max) {
        size_t n = std::min(max, available());
        uint64_t t = tail_.load(std::memory_order_relaxed);
        size_t pos = t % RING, first = std::min(n, RING - pos);
        memcpy(dst, &ring_[pos], first);
        memcpy(dst + first, &ring_[0], n - first);
        tail_.store(t + n, std::memory_order_release);
        return n;
    }

private:
    static void entry(void* a) { static_cast<NetStream*>(a)->run(); }

    static size_t onWrite(char* p, size_t sz, size_t cnt, void* ud) {
        auto* s = static_cast<NetStream*>(ud);
        const size_t total = sz * cnt;
        size_t off = 0;
        while (off < total) {
            if (s->abort_) return 0;
            uint64_t h = s->head_.load(std::memory_order_relaxed);
            size_t freeb = RING - (size_t)(h - s->tail_.load(std::memory_order_acquire));
            if (freeb == 0) { svcSleepThread(10000000ULL); continue; }   // buffer cheio: espera
            size_t chunk = std::min(total - off, freeb);
            size_t pos = h % RING, first = std::min(chunk, RING - pos);
            memcpy(&s->ring_[pos], p + off, first);
            memcpy(&s->ring_[0], p + off + first, chunk - first);
            s->head_.store(h + chunk, std::memory_order_release);
            off += chunk;
        }
        return total;
    }

    void run() {
        CURL* c = curl_easy_init();
        if (!c) { failed_ = true; done_ = true; return; }
        curl_easy_setopt(c, CURLOPT_URL, url_.c_str());
        curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(c, CURLOPT_USERAGENT, "Ressoa/1.0 (Nintendo Switch)");
        curl_easy_setopt(c, CURLOPT_CONNECTTIMEOUT, 10L);
        curl_easy_setopt(c, CURLOPT_BUFFERSIZE, 16384L);
        // Sem bundle de CAs no sysmodule: HTTPS sem verificação de certificado.
        // (Trade-off consciente: só áudio público CC é baixado; nenhum dado sensível trafega.)
        curl_easy_setopt(c, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(c, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, &NetStream::onWrite);
        curl_easy_setopt(c, CURLOPT_WRITEDATA, this);
        CURLcode rc = curl_easy_perform(c);
        long code = 0;
        curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &code);
        curl_easy_cleanup(c);
        if (!abort_ && (rc != CURLE_OK || code >= 400)) failed_ = true;
        done_ = true;
    }

    std::string url_;
    std::vector<uint8_t> ring_;
    std::atomic<uint64_t> head_{0}, tail_{0};
    std::atomic<bool> abort_{false}, done_{false}, failed_{false};
    Thread th_{};
    bool started_ = false;
};
