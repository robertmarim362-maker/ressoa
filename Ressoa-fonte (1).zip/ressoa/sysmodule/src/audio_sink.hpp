// ============================================================================
// Saída de áudio via audout (PCM s16 estéreo) + reamostrador linear.
// O audout do Switch roda a 48 kHz; MP3 geralmente é 44.1 kHz, então convertemos.
// ============================================================================
#pragma once
#include <switch.h>
#include <cstdlib>
#include <cstring>

// Reamostrador linear simples (barato o bastante para um sysmodule)
struct Resampler {
    double step = 1.0, frac = 0.0;
    s16 lastL = 0, lastR = 0;
    bool primed = false;

    void setup(u32 inHz, u32 outHz) { step = (double)inHz / (double)outHz; frac = 0; primed = false; }

    template <class F> void feed(s16 l, s16 r, F&& emit) {
        if (!primed) { lastL = l; lastR = r; primed = true; }
        while (frac < 1.0) {
            emit((s16)(lastL + (l - lastL) * frac), (s16)(lastR + (r - lastR) * frac));
            frac += step;
        }
        frac -= 1.0;
        lastL = l; lastR = r;
    }
};

class AudioSink {
public:
    static constexpr int NBUF = 4;          // buffers em voo (~170 ms de latência)
    static constexpr u32 FRAMES = 2048;     // frames por buffer

    bool init() {
        if (R_FAILED(audoutInitialize())) return false;
        rate_ = audoutGetSampleRate();
        const size_t bytes = FRAMES * 2 * sizeof(s16);   // múltiplo de 0x1000 (exigência do audout)
        for (int i = 0; i < NBUF; i++) {
            mem_[i] = (s16*)aligned_alloc(0x1000, bytes);
            if (!mem_[i]) return false;
            memset(mem_[i], 0, bytes);
            buf_[i] = AudioOutBuffer{};
            buf_[i].buffer = mem_[i];
            buf_[i].buffer_size = bytes;
            buf_[i].data_size = bytes;
            buf_[i].data_offset = 0;
        }
        ok_ = R_SUCCEEDED(audoutStartAudioOut());
        return ok_;
    }

    void shutdown() { if (ok_) { audoutStopAudioOut(); audoutExit(); ok_ = false; } }
    u32 rate() const { return rate_; }

    // Empilha um frame estéreo; envia o buffer ao audout quando enche.
    void pushFrame(s16 l, s16 r) {
        if (fill_ == 0) waitFree();
        int idx = (head_ + inflight_) % NBUF;
        mem_[idx][fill_ * 2] = l;
        mem_[idx][fill_ * 2 + 1] = r;
        if (++fill_ == FRAMES) {
            audoutAppendAudioOutBuffer(&buf_[idx]);
            inflight_++;
            fill_ = 0;
        }
    }

    // Descarta o buffer parcial (troca de faixa)
    void discard() { fill_ = 0; }

private:
    // Espera o audout liberar pelo menos um buffer (FIFO estrito: tocam na ordem)
    void waitFree() {
        while (inflight_ >= NBUF) {
            AudioOutBuffer* rel = nullptr; u32 cnt = 0;
            if (R_SUCCEEDED(audoutWaitPlayFinish(&rel, &cnt, 100000000ULL)) && cnt) {
                if ((int)cnt > inflight_) cnt = inflight_;
                inflight_ -= cnt;
                head_ = (head_ + cnt) % NBUF;
            }
        }
    }

    AudioOutBuffer buf_[NBUF];
    s16* mem_[NBUF] = {};
    int head_ = 0, inflight_ = 0;
    u32 fill_ = 0, rate_ = 48000;
    bool ok_ = false;
};
