// ============================================================================
// ressoad - sysmodule do Ressoa.
// Registra o serviço IPC "ressoa" e toca música em segundo plano.
// ============================================================================
#include <switch.h>
#include <curl/curl.h>
#include <cstring>
#include "ipc.hpp"
#include "player.hpp"
#include "store.hpp"

#define MAX_SESSIONS 4
#define RESSOA_ERR(n) MAKERESULT(345, (n))

static Handle g_port = INVALID_HANDLE;

// ---------------------------------------------------------------------------
// Configuração de runtime do libnx para sysmodule
// ---------------------------------------------------------------------------
extern "C" {
#define INNER_HEAP_SIZE 0x600000   // 6 MiB (ring 384K + curl/mbedtls + decoder). Ajuste se houver OOM.
size_t nx_inner_heap_size = INNER_HEAP_SIZE;
char   nx_inner_heap[INNER_HEAP_SIZE];

u32 __nx_applet_type = AppletType_None;
u32 __nx_fs_num_sessions = 1;

void __libnx_initheap(void) {
    extern char* fake_heap_start;
    extern char* fake_heap_end;
    fake_heap_start = nx_inner_heap;
    fake_heap_end   = nx_inner_heap + nx_inner_heap_size;
}

void __appInit(void) {
    if (R_FAILED(smInitialize())) diagAbortWithResult(MAKERESULT(Module_Libnx, LibnxError_InitFail_SM));

    if (hosversionGet() == 0) {
        if (R_SUCCEEDED(setsysInitialize())) {
            SetSysFirmwareVersion fw;
            if (R_SUCCEEDED(setsysGetFirmwareVersion(&fw)))
                hosversionSet(MAKEHOSVERSION(fw.major, fw.minor, fw.micro));
            setsysExit();
        }
    }
    if (R_FAILED(fsInitialize())) diagAbortWithResult(MAKERESULT(Module_Libnx, LibnxError_InitFail_FS));
    fsdevMountSdmc();

    // Registra o serviço IPC enquanto a sessão 'sm' ainda está aberta
    if (R_FAILED(smRegisterService(&g_port, smEncodeName(RESSOA_SERVICE), false, MAX_SESSIONS)))
        diagAbortWithResult(MAKERESULT(Module_Libnx, LibnxError_InitFail_SM));

    // Rede/entropia (falha aqui não é fatal: tentamos algumas vezes, o boot pode ser mais rápido que a rede)
    nifmInitialize(NifmServiceType_User);
    csrngInitialize();
    SocketInitConfig cfg = *socketGetDefaultInitConfig();
    cfg.tcp_tx_buf_size = 0x2000;  cfg.tcp_tx_buf_max_size = 0x8000;
    cfg.tcp_rx_buf_size = 0x8000;  cfg.tcp_rx_buf_max_size = 0x20000;
    cfg.udp_tx_buf_size = 0x400;   cfg.udp_rx_buf_size = 0x400;
    cfg.sb_efficiency = 1;
    for (int i = 0; i < 10; i++) {
        if (R_SUCCEEDED(socketInitialize(&cfg))) break;
        svcSleepThread(1000000000ULL);
    }
    smExit();
}

void __appExit(void) {
    socketExit();
    csrngExit();
    nifmExit();
    fsdevUnmountAll();
    fsExit();
}
}

// ---------------------------------------------------------------------------
// Servidor IPC mínimo (HIPC/CMIF "na mão" sobre svcReplyAndReceive)
// ---------------------------------------------------------------------------
static inline void* align16(void* p) { return (void*)(((uintptr_t)p + 15) & ~(uintptr_t)15); }

// Escreve a resposta CMIF no buffer TLS: [padding][CmifOutHeader][dados]
static void writeReply(Result rc, const void* out, size_t outsz) {
    HipcRequest h = hipcMakeRequestInline(armGetTls(), .num_data_words = (u32)(8 + (outsz + 3) / 4));
    CmifOutHeader* oh = (CmifOutHeader*)align16(h.data_words);
    oh->magic = CMIF_OUT_HEADER_MAGIC;
    oh->version = 0;
    oh->result = rc;
    oh->token = 0;
    if (outsz) memcpy(oh + 1, out, outsz);
}

// Retorna false se a sessão foi fechada pelo cliente
static bool handleRequest(Player& pl) {
    HipcParsedRequest r = hipcParseRequest(armGetTls());
    if (r.meta.type == CmifCommandType_Close) return false;
    if (r.meta.type != CmifCommandType_Request && r.meta.type != CmifCommandType_RequestWithContext) {
        writeReply(RESSOA_ERR(1), nullptr, 0);
        return true;
    }
    const CmifInHeader* ih = (const CmifInHeader*)align16(r.data.data_words);
    if (ih->magic != CMIF_IN_HEADER_MAGIC) { writeReply(RESSOA_ERR(2), nullptr, 0); return true; }

    // Copia argumentos ANTES de escrever a resposta (ela sobrescreve o TLS)
    const u32 cmd = ih->command_id;
    alignas(8) u8 in[32];
    memcpy(in, ih + 1, sizeof(in));
    u32 arg0; memcpy(&arg0, in, 4);

    union { u32 u; RessoaStatus st; RessoaPlaylistInfo pi; } out;
    memset(&out, 0, sizeof(out));
    size_t outsz = 0;
    Result res = 0;

    switch (cmd) {
        case RIPC_GetVersion:   out.u = RESSOA_VERSION; outsz = 4; break;
        case RIPC_GetStatus:    pl.status(out.st); outsz = sizeof(out.st); break;
        case RIPC_Play:         pl.play(); break;
        case RIPC_Pause:        pl.pause(); break;
        case RIPC_Toggle:       pl.toggle(); break;
        case RIPC_Next:         pl.next(); break;
        case RIPC_Prev:         pl.prev(); break;
        case RIPC_SetVolume:    pl.setVolume(arg0); break;
        case RIPC_SetRepeat:    pl.setRepeat(arg0); break;
        case RIPC_LoadPlaylist: {
            RessoaLoadArgs a; memcpy(&a, in, sizeof(a));
            if (!pl.loadPlaylist(a.index, a.start, a.shuffle != 0)) res = RESSOA_ERR(10);
            break;
        }
        case RIPC_LoadQueue:    if (!pl.loadQueueFile(arg0)) res = RESSOA_ERR(11); break;
        case RIPC_Reload:       pl.reloadPlaylists(); break;
        case RIPC_GetPlaylist:  pl.playlistInfo(arg0, out.pi); outsz = sizeof(out.pi); break;
        default:                res = RESSOA_ERR(3); break;
    }
    writeReply(res, &out, outsz);
    return true;
}

static void serve(Player& pl) {
    Handle handles[1 + MAX_SESSIONS];
    int n = 1;
    handles[0] = g_port;
    Handle replyTarget = INVALID_HANDLE;

    for (;;) {
        s32 idx = -1;
        Result rc = svcReplyAndReceive(&idx, handles, n, replyTarget, UINT64_MAX);
        replyTarget = INVALID_HANDLE;

        if (R_FAILED(rc)) {
            if (rc == KERNELRESULT(SessionClosed) && idx > 0) {   // cliente fechou a sessão
                svcCloseHandle(handles[idx]);
                handles[idx] = handles[--n];
            } else {
                svcSleepThread(1000000ULL);
            }
            continue;
        }
        if (idx == 0) {   // nova conexão no port
            Handle s;
            if (R_SUCCEEDED(svcAcceptSession(&s, g_port))) {
                if (n < 1 + MAX_SESSIONS) handles[n++] = s; else svcCloseHandle(s);
            }
            continue;
        }
        if (handleRequest(pl)) replyTarget = handles[idx];
        else { svcCloseHandle(handles[idx]); handles[idx] = handles[--n]; }
    }
}

int main(int argc, char** argv) {
    static Player player;
    curl_global_init(CURL_GLOBAL_DEFAULT);
    if (!player.init()) store::log("player.init falhou");
    serve(player);   // não retorna
    player.shutdown();
    curl_global_cleanup();
    return 0;
}
