// ============================================================================
// Player: fila, estado e motor de reprodução (download -> MP3 -> resample -> audout)
// Threads: IPC (principal, chama os métodos públicos) e 'engine' (decodifica/toca).
// ============================================================================
#pragma once
#include <switch.h>
#include <atomic>
#include <string>
#include <utility>
#include <vector>
#include "audio_sink.hpp"
#include "ipc.hpp"
#include "models.hpp"

class Player {
public:
    bool init();        // áudio + restaura último estado + inicia o motor
    void shutdown();

    // Comandos (thread-safe)
    void play();
    void pause();
    void toggle();
    void next();
    void prev();
    void setVolume(u32 v);
    void setRepeat(u32 r);
    bool loadPlaylist(u32 index, u32 start, bool shuffle);
    bool loadQueueFile(u32 start);
    void reloadPlaylists();
    void playlistInfo(u32 idx, RessoaPlaylistInfo& out);
    void status(RessoaStatus& out);

private:
    void engineLoop();
    void advanceLocked(int dir, bool manual);
    bool setQueue(std::vector<Track> tracks, u32 start, bool shuffle);
    void saveState();
    float gain() const { float v = volume_ / 100.0f; return v * v; }   // curva perceptual

    Mutex mtx_{};
    std::vector<Track> queue_;
    std::vector<std::pair<std::string, u32>> plInfo_;   // cache: nome + nº de faixas
    int idx_ = 0;
    u32 state_ = RS_Stopped, repeat_ = 0;
    bool shuffle_ = false, openRequested_ = false, dirty_ = false;
    u32 resumePos_ = 0;
    std::atomic<u32> volume_{60}, position_{0};
    std::atomic<bool> buffering_{false}, quit_{false};

    AudioSink sink_;
    Thread engine_{};
    bool engineStarted_ = false;
};
