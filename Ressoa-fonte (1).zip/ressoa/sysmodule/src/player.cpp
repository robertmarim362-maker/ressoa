// Implementação do Player. Decoder: dr_mp3 (API de frame, derivada do minimp3).
#define DR_MP3_IMPLEMENTATION
#define DR_MP3_NO_STDIO
#define DR_MP3_ONLY_MP3
#include "dr_mp3.h"

#include "player.hpp"
#include "netstream.hpp"
#include "store.hpp"
#include <algorithm>
#include <memory>
#include <random>

namespace {
// Lock RAII para o Mutex do libnx (não recursivo!)
struct Lock {
    Mutex* m;
    explicit Lock(Mutex* mm) : m(mm) { mutexLock(m); }
    ~Lock() { mutexUnlock(m); }
};

// URL de stream: usa a do JSON; se vazia, monta a do Jamendo a partir do id
std::string urlFor(const Track& t) {
    if (!t.url.empty()) return t.url;
    return "https://prod-1.storage.jamendo.com/?trackid=" + t.id + "&format=mp31";
}
}  // namespace

// ---------------------------------------------------------------------------
// Ciclo de vida
// ---------------------------------------------------------------------------
bool Player::init() {
    mutexInit(&mtx_);
    store::ensureDirs();
    if (!sink_.init()) { store::log("audout falhou ao iniciar"); return false; }

    Settings cfg;  store::load("settings.json", cfg);
    SavedState s;  bool had = store::load("state.json", s);
    {
        Lock l(&mtx_);
        volume_ = had ? (u32)std::clamp(s.volume, 0, 100) : (u32)std::clamp(cfg.default_volume, 0, 100);
        repeat_ = had ? (u32)s.repeat : 0;
        shuffle_ = had && s.shuffle;
        if (had && !s.queue.empty()) {
            queue_ = std::move(s.queue);
            idx_ = std::clamp(s.index, 0, (int)queue_.size() - 1);
            resumePos_ = (u32)std::max(0, s.position);
            position_ = resumePos_;
            openRequested_ = true;                              // abre quando o usuário der play
            state_ = cfg.autoresume ? RS_Playing : RS_Paused;   // "última música que eu escutava"
        }
    }
    reloadPlaylists();

    if (R_FAILED(threadCreate(&engine_, [](void* p) { static_cast<Player*>(p)->engineLoop(); },
                              this, nullptr, 0x20000, 0x2B, -2))) return false;
    threadStart(&engine_);
    engineStarted_ = true;
    return true;
}

void Player::shutdown() {
    quit_ = true;
    if (engineStarted_) { threadWaitForExit(&engine_); threadClose(&engine_); }
    saveState();
    sink_.shutdown();
}

// ---------------------------------------------------------------------------
// Comandos
// ---------------------------------------------------------------------------
void Player::play() {
    Lock l(&mtx_);
    if (queue_.empty()) return;
    if (state_ != RS_Playing) { state_ = RS_Playing; dirty_ = true; }
}
void Player::pause()  { Lock l(&mtx_); if (state_ == RS_Playing) { state_ = RS_Paused; dirty_ = true; } }
void Player::toggle() { bool p; { Lock l(&mtx_); p = (state_ == RS_Playing); } p ? pause() : play(); }
void Player::next()   { Lock l(&mtx_); advanceLocked(+1, true); }
void Player::prev() {
    Lock l(&mtx_);
    if (position_ > 3) { openRequested_ = true; resumePos_ = 0; position_ = 0; state_ = RS_Playing; dirty_ = true; }  // reinicia a faixa
    else advanceLocked(-1, true);
}
void Player::setVolume(u32 v) { volume_ = std::min<u32>(v, 100); }   // gravado no próximo save periódico
void Player::setRepeat(u32 r) { Lock l(&mtx_); repeat_ = std::min<u32>(r, 2); dirty_ = true; }

// Avança na fila. manual=true: botão do usuário (sempre dá a volta); manual=false: fim natural da faixa.
void Player::advanceLocked(int dir, bool manual) {
    if (queue_.empty()) return;
    int n = (int)queue_.size(), ni = idx_ + dir;
    openRequested_ = true; resumePos_ = 0; position_ = 0; dirty_ = true;
    if (!manual && repeat_ == 2) ni = idx_;                               // repetir faixa
    else if (ni >= n) {
        if (manual || repeat_ == 1) ni = 0;
        else { idx_ = 0; state_ = RS_Paused; return; }                    // fim da fila: para na faixa 1
    } else if (ni < 0) ni = n - 1;
    idx_ = ni;
    state_ = RS_Playing;
}

bool Player::setQueue(std::vector<Track> tracks, u32 start, bool shuffle) {
    if (tracks.empty()) return false;
    if (start >= tracks.size()) start = 0;
    if (shuffle) {   // Fisher-Yates mantendo a faixa escolhida em primeiro
        std::mt19937 rng((u32)armGetSystemTick());
        Track first = tracks[start];
        tracks.erase(tracks.begin() + start);
        std::shuffle(tracks.begin(), tracks.end(), rng);
        tracks.insert(tracks.begin(), first);
        start = 0;
    }
    Lock l(&mtx_);
    queue_ = std::move(tracks);
    idx_ = (int)start; resumePos_ = 0; position_ = 0;
    openRequested_ = true; state_ = RS_Playing; shuffle_ = shuffle; dirty_ = true;
    return true;
}

bool Player::loadPlaylist(u32 index, u32 start, bool shuffle) {
    std::vector<Playlist> pls;
    if (!store::load("playlists.json", pls) || index >= pls.size()) return false;
    return setQueue(pls[index].tracks, start, shuffle);
}

bool Player::loadQueueFile(u32 start) {
    std::vector<Track> q;
    if (!store::load("queue.json", q)) return false;
    return setQueue(std::move(q), start, false);
}

void Player::reloadPlaylists() {
    std::vector<Playlist> pls;
    store::load("playlists.json", pls);
    std::vector<std::pair<std::string, u32>> info;
    for (auto& p : pls) info.emplace_back(p.name, (u32)p.tracks.size());
    Lock l(&mtx_);
    plInfo_ = std::move(info);
}

void Player::playlistInfo(u32 idx, RessoaPlaylistInfo& o) {
    memset(&o, 0, sizeof(o));
    Lock l(&mtx_);
    o.count = (u32)plInfo_.size();
    if (idx < plInfo_.size()) {
        strncpy(o.name, plInfo_[idx].first.c_str(), sizeof(o.name) - 1);
        o.tracks = plInfo_[idx].second;
    }
}

void Player::status(RessoaStatus& o) {
    memset(&o, 0, sizeof(o));
    Lock l(&mtx_);
    o.state = (state_ == RS_Playing && buffering_) ? RS_Buffering : state_;
    o.index = idx_; o.count = (u32)queue_.size();
    o.volume = volume_; o.position = position_; o.repeat = repeat_; o.shuffle = shuffle_;
    if (!queue_.empty()) {
        const Track& t = queue_[idx_];
        o.duration = (u32)t.duration;
        strncpy(o.title, t.title.c_str(), sizeof(o.title) - 1);
        strncpy(o.artist, t.artist.c_str(), sizeof(o.artist) - 1);
    }
}

void Player::saveState() {
    SavedState s;
    {
        Lock l(&mtx_);
        s.queue = queue_; s.index = idx_; s.position = (int)position_;
        s.volume = (int)volume_; s.repeat = (int)repeat_; s.shuffle = shuffle_;
        dirty_ = false;
    }
    store::save("state.json", s);
}

// ---------------------------------------------------------------------------
// Motor de reprodução
// ---------------------------------------------------------------------------
void Player::engineLoop() {
    std::unique_ptr<NetStream> stream;
    drmp3dec dec; drmp3dec_init(&dec);
    static uint8_t inbuf[16 * 1024];
    size_t inlen = 0;
    short pcm[DRMP3_MAX_SAMPLES_PER_FRAME];
    Resampler rs;
    Track playing;
    bool needInit = true;
    u64 skipFrames = 0, decoded = 0;
    u32 hz = 44100, curResume = 0;
    int fails = 0;
    u64 lastSave = armGetSystemTick();

    while (!quit_) {
        bool doOpen = false, doSave = false;
        u32 st;
        {
            Lock l(&mtx_);
            st = state_;
            if (openRequested_ && st == RS_Playing && !queue_.empty()) {
                doOpen = true; playing = queue_[idx_]; curResume = resumePos_;
                openRequested_ = false; position_ = curResume;
            }
            if (dirty_ || (st == RS_Playing && armTicksToNs(armGetSystemTick() - lastSave) > 15000000000ULL)) doSave = true;
        }
        if (doSave) { saveState(); lastSave = armGetSystemTick(); }

        if (doOpen) {   // nova faixa: reinicia stream e decoder
            stream.reset();
            sink_.discard();
            stream.reset(new NetStream(urlFor(playing)));
            inlen = 0; drmp3dec_init(&dec);
            needInit = true; decoded = 0; skipFrames = 0;
            buffering_ = true;
            if (curResume == 0) store::appendHistory(playing);   // histórico recente
        }

        if (!stream || st != RS_Playing) { svcSleepThread(20000000ULL); continue; }   // pausado/parado

        if (inlen < sizeof(inbuf)) inlen += stream->read(inbuf + inlen, sizeof(inbuf) - inlen);

        drmp3dec_frame_info info{};
        int n = drmp3dec_decode_frame(&dec, inbuf, (int)inlen, pcm, &info);
        if (info.frame_bytes > 0) {
            inlen -= (size_t)info.frame_bytes;
            memmove(inbuf, inbuf + info.frame_bytes, inlen);
        }

        if (n > 0) {
            buffering_ = false;
            if (needInit) {   // primeiro frame: define taxa e quanto pular para retomar a posição salva
                hz = (u32)info.hz;
                rs.setup(hz, sink_.rate());
                skipFrames = (u64)curResume * hz;
                needInit = false;
            }
            const int ch = info.channels;
            int from = 0;
            if (skipFrames) {
                u64 d = std::min<u64>(skipFrames, (u64)n);
                skipFrames -= d; from = (int)d; decoded += d;
            }
            const float g = gain();
            for (int i = from; i < n; i++) {
                s16 l = pcm[i * ch];
                s16 r = (ch > 1) ? pcm[i * ch + 1] : l;
                rs.feed((s16)(l * g), (s16)(r * g), [&](s16 a, s16 b) { sink_.pushFrame(a, b); });
            }
            decoded += (u64)(n - from);
            position_ = (u32)(decoded / hz);
            if (position_ >= 5) fails = 0;
        } else if (info.frame_bytes == 0) {   // precisa de mais dados
            if (stream->done() && stream->available() == 0) {   // acabou (ou caiu)
                bool failed = stream->failed();
                stream.reset();
                {
                    Lock l(&mtx_);
                    if (failed) {
                        store::log("falha de rede: %s", playing.title.c_str());
                        if (++fails <= 2) { openRequested_ = true; resumePos_ = position_; }   // tenta de novo
                        else if (fails <= 5) advanceLocked(+1, false);                          // pula a faixa
                        else { state_ = RS_Error; fails = 0; dirty_ = true; }
                    } else {
                        advanceLocked(+1, false);   // fim natural da faixa
                    }
                }
                if (failed) svcSleepThread(1000000000ULL);
            } else {
                buffering_ = true;
                svcSleepThread(5000000ULL);
            }
        }
    }
}
